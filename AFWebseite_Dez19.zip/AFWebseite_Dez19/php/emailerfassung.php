<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    
    <title>Make Up Blog</title>
    
    <link rel="stylesheet" href="../css/stylesheet_lips_eyes_mist_trans.css">
    <link href="https://fonts.googleapis.com/css?family=Quicksand|Raleway" rel="stylesheet">
	
	<script src="https://cdn.rawgit.com/hilios/jQuery.countdown/2.2.0/dist/jquery.countdown.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>
	  
  </head>
  <body>
    <div class="logo">     
	</div>
	
	<nav class="navbar navbar-expand-sm navbar-dark bg-warning">	
	    <div class="collapse navbar-collapse" id="navbars">
	    	<ul class="navbar-nav mr-auto">
	        	<li class="nav-item">
	            	<a class="nav-link" href="../index.html">Home</span></a>
	        	</li>
	          	<li class="nav-item">
	            	<a class="nav-link" href="../html/lips.html">Lips</a>
	        	</li>
	          	<li class="nav-item">
	            	<a class="nav-link" href="../html/eyes.html">Eyes</a>
	          	</li>
	          	<li class="nav-item">
	            	<a class="nav-link" href="../html/face.html">Face</a>
	          	</li>
	          	<li class="nav-item">
	            	<a class="nav-link" href="../html/mist.html">Mist</a>
	          	</li>
	          	<li class="nav-item dropdown">
	            	<a class="nav-link dropdown-toggle" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Us</a>
	            	<div class="dropdown-menu" aria-labelledby="dropdown01">
	              		<a class="dropdown-item" href="html/anja.html">Anja</a>
	              		<a class="dropdown-item" href="html/mel.html">Mel</a>
	            	</div>
	          	</li>
				<li class="nav-item active">
	            	<a class="nav-link" href="../php/emailerfassung.php">NL Anmeldung</a>
	          	</li>
	     	</ul>
	   	</div>
	</nav>  
    
	<nlanmeldung>
		<h2>Newsletter Anmeldung</h2>
		<p>Felder mit * sind Pflichtfelder</p>
		<form action="emailverarbeitung.php" method="post" name="registration">
		  <table>
			<tr>
			  <td>Vorname *:</td>
			  <td><input type="text" name="vorname" value="" /></td>
			</tr>
			<tr>
			  <td>Nachname *:</td>
			  <td><input type="text" name="nachname" value="" /></td>
			</tr>
			<tr>
			  <td>Email *:</td>
			  <td><input type="email" name="email" value="" /></td>
			</tr>
			<tr>
			  <td>Newsletter Abo:&nbsp;</td>
			  <td><input type="radio" name="newsletter" value="ja" checked>Ja</td>
			  <td><input type="radio" name="newsletter" value="Nein">Nein</td>
			</tr>
		  </table>
		  <br>
		  <button type="submit" name="senden" value="speichern">senden</button>
		  <input type="hidden" name="datum" type="date" value="<?php echo date('d.m.Y'); ?>"> 
		</form>
		
		
		<script>
			jQuery.validator.addMethod(
			  "regex",
			   function(value, element, regexp) {
				   if (regexp.constructor != RegExp)
					  regexp = new RegExp(regexp);
				   else if (regexp.global)
					  regexp.lastIndex = 0;
					  return this.optional(element) || regexp.test(value);
			   },"erreur expression reguliere"
			);
			$("form[name='registration']").validate({
		    // Specify validation rules
		    rules: {
		      // The key name on the left side is the name attribute
		      // of an input field. Validation rules are defined
		      // on the right side
		      vorname: "required",
		      nachname: "required",
		      email: {
		        required: true,
		        // Specify that email should be validated
		        // by the built-in "email" rule
		        email: true,
				regex: /^\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i
		      }
		    },
		    // Specify validation error messages
		    messages: {
		      vorname: "&nbsp;Bitte geben Sie Ihren Vornamen an",
		      nachname: "&nbsp;Bitte geben Sie Ihren Nachnamen an",
		      email: "&nbsp;Bitte geben Sie eine g&uuml;ltige Email ein"
		    },
		    // Make sure the form is submitted to the destination defined
		    // in the "action" attribute of the form when valid
		    submitHandler: function(form) {
		      form.submit();
		    }
		  });	
		</script>


		<p><br><b><span id="clock"></span></b></p>

		<script>
			$('#clock').countdown('2019/12/31 24:00:00')
			.on('update.countdown', function(event) {
			  var format = '%H:%M:%S';
			  if(event.offset.totalDays > 0) {
				format = '%-d Tag%!d:e; ' + format;
			  }
			  if(event.offset.weeks > 0) {
				format = '%-w Woche%!w:n; ' + format;
			  }
			  $(this).html('Die Zeit bis zum neuen Newsletter! ' + event.strftime(format));
			})
			.on('finish.countdown', function(event) {
			  $(this).html('Der neue Newsletter ist da!')
				.parent().addClass('disabled');

			});
		</script>
		
	</nlanmeldung>

<footer>
	Made by Anja and Mel; 2019      
</footer>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></
      
</body>