<?php
	/**
    * Datei Name, wo die Daten gespeichert werden
        sollen
    */
    $dateiname = 'daten.csv';
    /**
    * Pr�fen ob die Variable ein Wert zugewiesen
        wurde. Ansonsten werden diese Variablen
        deklariert.
    */
    if (!isset($_POST['vorname'])) $_POST['vorname'] = '';
    if (!isset($_POST['nachname'])) $_POST['nachname'] = '';
    if (!isset($_POST['email'])) $_POST['email'] = '';
    if (!isset($_POST['newsletter'])) $_POST['newletter'] = '';
    if (!isset($_POST['datum'])) $_POST['datum'] = '';
    if (!isset($_POST['senden'])) $_POST['senden'] = '';
    
    $meldung = '';
    /**
    * Pr�fen der Variable $_POST['senden'] ob diese
        ein Wert hat.
    */
    if ($_POST['senden'] == 'speichern') {
        /**
        * Zeile aufbauen, die in die CSV-Datei am Ende
            geschrieben werden soll
        */

        $inhalt = $_POST['vorname'].';'.$_POST['nachname'].';'.$_POST['email'].';'.$_POST['newsletter'].';'.$_POST['datum']."
        ";
        //print "<br>".$inhalt."<br>";
        
        /**
        * Datei �ffnen und den Dateizeiger auf das Ende der CSV Datei legen, wenn die Datei noch nicht vorhanden ist wird versucht
            diese anzulegen. Wichtig ist, dass die Skriptdatei die Rechte zum anlegen einer Datei hat.
        */
        $handle = @fopen($dateiname, "ab+");
        /**
        * Schreiben der Zeile, in der CSV Datei
        */
        fwrite($handle, $inhalt);
        /**
        * Datei wieder schliessen
        */
        fclose ($handle);
        /**
        * Pr�fen ob die CSV Datei existiert
        */
        if (file_exists($dateiname) == true) {
            /**
            * Die schreib Rechte �ndern bei der CSV Datei, damit das n�chste mal diese beschrieben werden kann.
            */
            @chmod ($dateiname, 0757);
        }
        /**
        *  Ausgabemeldung erstellen
        */
        $meldung = "<font color='green'>Daten wurden mit folgenden Daten gespeichert:<br></font>
                    <table>
                        <tr>
                          <td>Vorname:</td>
                          <td>".$_POST['vorname']."</td>
                        </tr>
                        <tr>
                          <td>Nachname:</td>
                          <td>".$_POST['nachname']."</td>
                        </tr>
                        <tr>
                          <td>Email:</td>
                          <td>".$_POST['email']."</td>
                        </tr>
                        <tr>
                          <td>Newsletter Abo:</td>
                          <td>".$_POST['newsletter']."</td>
                        </tr>
                      </table>";
         
    }
    /**
    * Pr�fen ob eine Ausgabemeldung in der Variable $meldung hinterlegt wurde, wenn eine Ausgabemeldung vorhanden ist wird diese per
        Echo ausgegeben.
    */
    if ($meldung != '') echo $meldung; 
?>
<br>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" 
       method="post">
  <table>
    <tr>
      <td>Vorname:</td>
      <td><input type="text" name="vorname" value=""/></td>
    </tr>
    <tr>
      <td>Nachname:</td>
      <td><input type="text" name="nachname" value=""/></td>
    </tr>
    <tr>
      <td>Email:</td>
      <td><input type="email" name="email" value=""/></td>
    </tr>
    <tr>
      <td>Newsletter Abo:</td>
      <td><input type="radio" name="newsletter" value="ja">Ja</td>
      <td><input type="radio" name="newsletter" value="Nein">Nein</td>
    </tr>
  </table>
  <button type="submit" name="senden" value="speichern">senden</button>
  <input type="hidden" name="datum" type="date" value="<?php echo date('d.m.Y'); ?>"> 
  
</form>