<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    
    <title>Make Up Blog</title>
    
    <link rel="stylesheet" href="../css/stylesheet_lips_eyes_mist_trans.css">
    <link href="https://fonts.googleapis.com/css?family=Quicksand|Raleway" rel="stylesheet">
	  
  </head>
  <body>
    <div class="logo">     
	</div>
	
	<nav class="navbar navbar-expand-sm navbar-dark bg-warning">	
	    <div class="collapse navbar-collapse" id="navbars">
	    	<ul class="navbar-nav mr-auto">
	        	<li class="nav-item">
	            	<a class="nav-link" href="../index.html">Home</span></a>
	        	</li>
	          	<li class="nav-item">
	            	<a class="nav-link" href="../html/lips.html">Lips</a>
	        	</li>
	          	<li class="nav-item">
	            	<a class="nav-link" href="../html/eyes.html">Eyes</a>
	          	</li>
	          	<li class="nav-item">
	            	<a class="nav-link" href="../html/face.html">Face</a>
	          	</li>
	          	<li class="nav-item">
	            	<a class="nav-link" href="../html/mist.html">Mist</a>
	          	</li>
	          	<li class="nav-item dropdown">
	            	<a class="nav-link dropdown-toggle" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Us</a>
	            	<div class="dropdown-menu" aria-labelledby="dropdown01">
	              		<a class="dropdown-item" href="../html/anja.html">Anja</a>
	              		<a class="dropdown-item" href="../html/mel.html">Mel</a>
	            	</div>
	          	</li>
				<li class="nav-item active">
	            	<a class="nav-link" href="../php/emailerfassung.php">NL Anmeldung</a>
	          	</li>
	     	</ul>
	   	</div>
	</nav>  
	
<?php
	/**
    * Datei Name, wo die Daten gespeichert werden
        sollen
    */
    $dateiname = 'daten.csv';
    /**
    * Pr�fen ob die Variable ein Wert zugewiesen
        wurde. Ansonsten werden diese Variablen
        deklariert.
    */
    if (!isset($_POST['vorname'])) $_POST['vorname'] = '';
    if (!isset($_POST['nachname'])) $_POST['nachname'] = '';
    if (!isset($_POST['email'])) $_POST['email'] = '';
    if (!isset($_POST['newsletter'])) $_POST['newsletter'] = '';
    if (!isset($_POST['datum'])) $_POST['datum'] = '';
    if (!isset($_POST['senden'])) $_POST['senden'] = '';
    
    $meldung = '';
    /**
    * Pr�fen der Variable $_POST['senden'] ob diese
        ein Wert hat.
    */
    if ($_POST['senden'] == 'speichern') {
        /**
        * Zeile aufbauen, die in die CSV-Datei am Ende
            geschrieben werden soll
        */

        $inhalt = $_POST['vorname'].';'.$_POST['nachname'].';'.$_POST['email'].';'.$_POST['newsletter'].';'.$_POST['datum']."\r\n";
        //print "<br>".$inhalt."<br>";
        
        /**
        * Datei �ffnen und den Dateizeiger auf das Ende der CSV Datei legen, wenn die Datei noch nicht vorhanden ist wird versucht
            diese anzulegen. Wichtig ist, dass die Skriptdatei die Rechte zum anlegen einer Datei hat.
        */
        $handle = @fopen($dateiname, "ab+");
        /**
        * Schreiben der Zeile, in der CSV Datei
        */
        fwrite($handle, $inhalt);
        /**
        * Datei wieder schliessen
        */
        fclose ($handle);
        /**
        * Pr�fen ob die CSV Datei existiert
        */
        if (file_exists($dateiname) == true) {
            /**
            * Die schreib Rechte �ndern bei der CSV Datei, damit das n�chste mal diese beschrieben werden kann.
            */
            @chmod ($dateiname, 0757);
        }
		/**
        * Pr�fen ob eine Newsletteranmeldung vorliegt
        */
		if ($_POST['newsletter'] == "ja"){
			
			/**
			*  Email Ausgabe aufbreiten
			*/
			$empfaenger = $_POST['email'];
			$betreff = "Best�tigung der Anmeldung";
			$from = "From: Melja Beauty <anja.fahrni@bluewin.ch>";
			$text = "Danke f�r Ihre Registration\r\n";
			$text .= "Sie haben sich mit folgenden Angaben Registriert:\r\n";
			$text .= "Vorname: ".$_POST['vorname']."\r\n";
			$text .= "Nachname: ".$_POST['nachname']."\r\n";
			$text .= "Email: ".$_POST['email']."\r\n";
			$text .= "Newsletter Abo: ".$_POST['newsletter']."\r\n\r\n";
			$text .= "Liebe Gr�sse Ihr Melja Beauty Team";
			
			/**
			*  Email versenden
			*/
			mail($empfaenger, $betreff, $text, $from);
			
			/**
			*  Ausgabemeldung erstellen
			*/
			$meldung = "<font color='green'>Daten wurden mit folgenden Daten gespeichert:<br></font>
						<table>
							<tr>
							  <td>Vorname:</td>
							  <td>".$_POST['vorname']."</td>
							</tr>
							<tr>
							  <td>Nachname:</td>
							  <td>".$_POST['nachname']."</td>
							</tr>
							<tr>
							  <td>Email:</td>
							  <td>".$_POST['email']."</td>
							</tr>
							<tr>
							  <td>Newsletter Abo:</td>
							  <td>".$_POST['newsletter']."</td>
							</tr>
						  </table>";
			 
		} else {
		/**
			*  Ausgabemeldung erstellen
			*/
			$meldung = "<font color='green'>Daten wurden mit folgenden Daten gespeichert:<br></font>
						<table>
							<tr>
							  <td>Vorname:</td>
							  <td>".$_POST['vorname']."</td>
							</tr>
							<tr>
							  <td>Nachname:</td>
							  <td>".$_POST['nachname']."</td>
							</tr>
							<tr>
							  <td>Email:</td>
							  <td>".$_POST['email']."</td>
							</tr>
							<tr>
							  <td>Newsletter Abo:</td>
							  <td>".$_POST['newsletter']."</td>
							</tr>
						  </table>
						  <br><p>Sie haben sich <b>nicht</b> f&uuml;r den Newsletter <b>registriert!</b></p>";
			 
		}
	}
    /**
    * Pr�fen ob eine Ausgabemeldung in der Variable $meldung hinterlegt wurde, wenn eine Ausgabemeldung vorhanden ist wird diese per
        Echo ausgegeben.
    */
    if ($meldung != '') echo $meldung; 
?>

<br>
<a href="emailerfassung.php"><button>Noch eine Erfassung</button></a>
<a href="../index.html"><button>Abbruch</button></a>

<footer>
	Made by Anja and Mel; 2019      
</footer>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
      
</body>